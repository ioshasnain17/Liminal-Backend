<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
<h1>Please use this code in liminal app to verify your account</h1>
<p>{{$resetCode}}</p>
</body>
</html>
