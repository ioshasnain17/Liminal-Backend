<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
<h1>Please use this code in liminal app to verify your account</h1>
<p><?php echo e($resetCode); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\chatapp\resources\views/email.blade.php ENDPATH**/ ?>